describe("Leased Line Solution test", function() {
  before(function() {
    cy.fixture("example").then(function(data) {
      this.data = data;

      cy.login(Cypress.env("url"), "shehzad", "Lahore2@");
      cy.wait(60000);
    });

    const clear = Cypress.LocalStorage.clear

Cypress.LocalStorage.clear = function (keys, ls, rs) {
  // do something with the keys here
  if (keys) {
    return clear.apply(this, arguments)
  }
}

  });

  this.beforeEach(function() {
    Cypress.Cookies.preserveOnce("FedAuth");
  });

    it("Select quote to add solution", function() {
      cy.reload();
      cy.wait(20000);
      cy.get('..gn-icon-menu').click()
      cy.contains("Quotes").click({ force: true });
      cy.get("#txtentitygrid_Input").type("QUO-1047791-11");
      cy.wait(8000);
      cy.get(".k-grid-content")
        .contains("QUO-1047791-11")
        .click();
      // Add solution and then add leased line item
      cy.get("#AddIcon").click();
      cy.get("#btnSolutionType1").click();
      cy.get("#Next").click({ force: true });
      cy.wait(8000);
    });

  it("Selecting a product", function() {
    cy.reload();
    cy.wait(20000);
    // cy.visit(
    //   "https://timicouat.servicepathlive.com/Spa/#/quotes/id/1047791-06/solutionslist/leasedlinesolution/38978-c"
    // );

//    cy.wait(30000);
    cy.get("#AddServiceIcon").click();
    // SELECT Circuit Purpose
    cy.wait(4000);
    //select circuit purpose
    cy.get(".k-i-arrow-60-down")
      .eq(1)
      .click({ force: true });
    cy.get("#CircuitPurpose_listbox")
      .contains("Primary Circuit Only")
      .click({force: true});
cy.wait(3000)
      // select Access Type
cy.get(".k-i-arrow-60-down")
      .eq(4).click({ force: true });

      cy.get("#select_localdatacomb_select_AccessTypes_listbox").contains('Direct)').click({force: true})

      // select serviceType
      cy.get(".k-i-arrow-60-down")
      .eq(5).click({ force: true });
    cy.get("#select_localdatacomb_select_ServiceTypes_listbox").contains(
      "DIA (Direct Internet Access)"
    ).click({force: true})

    // Select Bearer
    cy.get(".k-i-arrow-60-down").eq(6).click({ force: true });
    cy.get("#Bearer_listbox").contains("100 Mbps").click({force: true})

//Select Bandwidth
cy.get("#select_localdatacomb_select_Bandwidth_taglist").click({force: true})
    cy.get("#select_localdatacomb_select_Bandwidth_listbox").contains("30 Mbps").click({force: true})

    //  Type address code
    cy.get("#txtPostcode_Input").type("NG242TN");
    cy.get("#SearchPostcode").click();
    cy.get("#Provider_4").click();
    cy.get("#Search").click();

    // select item and click on save button
    // tr td input[type=radio]
   // cy.get('tr td input[type=radio]').click()

// Get values for verification 
// cy.get('.k-alt > :nth-child(10)').should('have.text', '£195.00')
// cy.get('.k-alt > :nth-child(8)').should('have.text', '36 months')

    cy.get('.k-alt > :nth-child(1)').click()
        //click on save button
        cy.get('[data-uipath="GenericPopupForm/PopupSave"]').click()
  });

  
it('solution total verification', function(){
    // Total Recurring value verification
    cy.get('[data-uipath="StandardSolutionTotal"]').eq(0).should('contain.text','£308.35')
    // verify one time value
    cy.get('[data-uipath="StandardSolutionTotal"]').eq(1).should('contain.text','£0.00')
})

// Test Case 2 for adding items of "Primary Circuit with Failover"
it("Add item from Primary circuit with failover", function(){

    // click on button to add new item 
    cy.get("#AddServiceIcon").click();

       //select circuit purpose
    cy.get(".k-i-arrow-60-down")
      .eq(1)
      .click({ force: true });
    cy.get("#CircuitPurpose_listbox")
      .contains("Primary Circuit with Failover")
      .click({force: true});
cy.wait(3000)

      // select Failover Type
cy.get(".k-i-arrow-60-down")
      .eq(2).click({ force: true });
      cy.wait(2000)
      cy.get("#select_localdatacomb_select_FailoverTypes_listbox").contains('RAO2').click({force : true})

// Select A End Resilience
cy.get(".k-i-arrow-60-down")
      .eq(3).click({ force: true });
cy.get('#IncludeResilienceInAEnd_listbox').contains('Yes').click({force : true})


// Select Access Type 
cy.get(".k-i-arrow-60-down")
      .eq(4).click({ force: true });
cy.get('#select_localdatacomb_select_AccessTypes_listbox').contains('EAD (Ethernet Access Direct)').click({force : true})

      // select serviceType
      cy.get(".k-i-arrow-60-down")
      .eq(5).click({ force: true });
    cy.get("#select_localdatacomb_select_ServiceTypes_listbox").contains(
      "DIA (Direct Internet Access)"
    ).click({force: true})

    // Select Bearer
    cy.get(".k-i-arrow-60-down").eq(6).click({ force: true });
    cy.get("#Bearer_listbox").contains("100 Mbps").click({force: true})

//Select Bandwidth
cy.get("#select_localdatacomb_select_Bandwidth_taglist").click({force: true})
    cy.get("#select_localdatacomb_select_Bandwidth_listbox").contains("30 Mbps").click({force: true})

    //  Type address code
    cy.get("#txtPostcode_Input").type("NG242TN");
    cy.get("#SearchPostcode").click();
    cy.get("#Provider_5").click();
    cy.get("#Search").click();

    // select item and click on save button
    // tr td input[type=radio]
   // cy.get('tr td input[type=radio]').click()

// Get values for verification 
// cy.get('.k-alt > :nth-child(10)').eq(1).should('have.text', '£685.33')
// cy.get('.k-alt > :nth-child(8)').eq(1).should('have.text', '36 months')

    cy.get('.k-alt > :nth-child(1)').click()
        //click on save button
        cy.get('[data-uipath="GenericPopupForm/PopupSave"]').click()

})

});

// Bearer_listbox
// 