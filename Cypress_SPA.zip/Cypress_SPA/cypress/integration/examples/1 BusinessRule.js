
describe("this is business rule test class", function () {
  before(function () {
    cy.fixture("example").then(function (data) {
      this.data = data;
    });
    // login is moved to commands.js
    // cy.login("selenium.servicepathlive.com", "shehzad", "ddddd*");
    cy.login(Cypress.env("url"), "musman", "Qqqqq2@");
    // login Verification
    cy.get('[data-uipath="SalesNavigator"]').should(
      "contain.text",
      "Sales Navigator"
    );
  });
  this.beforeAll(function () {
    Cypress.Cookies.preserveOnce("FedAuth");
    // Cypress.Cookies.defaults({
    //   whitelist: "FedAuth"
    // });
  });

  beforeEach(() => {
    Cypress.Cookies.defaults({
      whitelist: "FedAuth",
    });
    cy.restoreLocalStorage();
  });

  afterEach(() => {
    cy.saveLocalStorage();
  });

  it("search product version and select it", function () {
    cy.wait(5000);
    cy.contains("Portfolios").click({ force: true });

    cy.SelectProduct("CONFIGURED PRODUCT");
    cy.wait(5000);

    cy.get(
      '[data-uipath="ProductVersionsSummary/SideBar/Root/configurator"]'
    ).click();
    cy.wait(5000);
  });

  it("Search a product in configurator", function () {
    // click on quick search
    cy.contains("Quick Search").click({ force: true });

    // type is search field
    cy.get('[data-uipath="SearchTextBox"]').eq(0).type("testing");

    // Click on arrow to expand search results
    cy.get('[data-uipath="QuickSearch/SearchProductTree"] .k-i-expand').click({
      force: true,
    });

    // select item

    // cy.get('#SingleItemModels\/a9a39a30b7bfffb2\/Active\/20200221154014 > .cm-left-col')
    // cy.get('.k-first > :nth-child(1) > .k-in > .cg > .cm-left-col')

    // VUE Draggable

    const source =
      '[data-uipath="ConfiguratorTab/Configurator/ConfiguratorModelTreeView"] .TreeLevelOne :eq(0)';
    const target =
      '[data-uipath="QuickSearch/SearchProductTree"] .TreeLevelTwo :eq(0)';

    cy.get("[data-uipath='QuickSearch/SearchProductTree'] .TreeLevelTwo")
      .eq(0)
      .trigger("mousedown", { button: 0 });
    cy.wait(1000);
    cy.get(".TreeLevelOne")
      .contains("Group 1")
      .trigger("mousemove")
      .trigger("mouseleave");

    cy.log("drag drop is done and clicking on 1st group");
    cy.get(
      '[data-uipath="QuickSearch/SearchProductTree"] .TreeLevelTwo :eq(1)'
    ).click();
    // const itemsSelector = 'li'
    // const targetIndex = 0
    // // the drop command is defined in ../support/commands.js
    // cy.drop(source, listSelector)

    // cy.get(source).drop(listSelector, { itemsSelector, targetIndex })

    // const source = '[data-uipath="QuickSearch/SearchProductTree"] .TreeLevelTwo :eq(0)';

    // const target = '[data-uipath="ConfiguratorTab/Configurator/ConfiguratorModelTreeView"] .TreeLevelOne';

    // cy.get(source).drag(target);

    // require('@4tw/cypress-drag-drop')
    //cy.get(source).drag()

    // cy.findByTestId('item-1').drag('[data-testid="right"]')
  });

  // it('add business rule', function(){
  //   cy.get('[data-uipath="AddRule"]').click()
  //   cy.get('[data-uipath="AddRulesPopup/AddRule"]').click()

  //       })
});

// describe("2nd Function to add Business Rules", function () {
//   it("add section", function () {
//     // click on add section button to open it
//     cy.get('[data-uipath="DefinitionTab/AddSections"]').click({ force: true });
//     //  cy.wait(2000)
//     cy.get('[data-uipath="AddSectionPopup/AddLogicStep"]').click({
//       force: true,
//     });
//     //  cy.get('[data-uipath="DefinitionTab/ElseSection/DropdownArrow0"]').click({force : true})
//     // click on add section button to close it
//     cy.wait(1000);

//     cy.get("#maintoolbar").click({ force: true });
//     cy.wait(1000);
//   });

// it("Select Values in IF condition", function () {
//   //Click on arrow for 1st drop down to select product
//   cy.get(".k-select").eq(0).click({ force: true });

//   // Selecting product from drop down
//   cy.get("#If_AOperand_0_ValueProviderGetItem0_listbox .k-item")
//     .contains("New Label Item")
//     .click({ force: true });
// });
// });
