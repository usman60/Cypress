class HomePage {
  getName() {
    return cy.get(":nth-child(1) > .form-control")
  }

  getEntrepreneur() {
    return cy.get("#inlineRadio3")
  }
}
export default HomePage;
