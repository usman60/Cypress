class ProductPage {
  shopButton() {
    return cy.contains("Shop");
  }
  AddtoCart() {
    return cy.get(".card-footer > .btn");
  }
  selectProduct() {
    return cy.get("app-card");
  }
CheckoutButton()
{
    return cy.get("#navbarResponsive").contains("Checkout")
}

}
export default ProductPage;
