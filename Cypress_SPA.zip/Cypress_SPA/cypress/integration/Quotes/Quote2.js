/// <reference types="Cypress" />
describe("this is test for servicePath Quotes", function () {
    before(function () {
      cy.fixture("example").then(function (data) {
        this.data = data;
      });
      // login is moved to commands.js
      //cy.login(Cypress.env("url"), "shehzad", "ddddd*");
    });
  
    beforeEach(() => {
      Cypress.Cookies.defaults({
        whitelist: "FedAuth",
      });
      cy.restoreLocalStorage();
    });
    afterEach(() => {
      cy.saveLocalStorage()
      });
  
    
    //Create New Quote
  it('Login test', function(){

// cy.login()
  cy.login(Cypress.config().baseUrl, "shehzad", "ddddd*")
  
  })
  
it("it is test for runnig different scenarios", function(){

  cy.visit('https://selenium.solutionengine.co/Spa/#/quotes/id/86889-01/solutionslist/standardsolution/40564-a', {timeout:60000})

  cy.wait(10000)

//  //delete product if available
// cy.get('[data-uipath="ProductGrid"] tr').then(function(noItem){
// const  len= noItem.length;
// cy.log(len);
// if(len>2)
// {
// // Add products
//   cy.get('[data-uipath="ProductGrid"] input:eq(0)').click();
//   cy.get('[data-uipath="DeleteLineItemBtn"]', {timeout: 60000}).click()
//   cy.get('[data-uipath="YesBtn"]', {timeout: 60000}).click()

// }
// else
// {
//   cy.log('no product to delete')
// }


// }) 

// cy.wait(500000)
 
 
 
  cy.get('[data-uipath="QuoteDetail/sidebar/Root/pricing"]', {timeout : 10000}).click()
  // cy.wait(5000)
  // cy.contains("CY-NoDyn111222", {timeout:10000}).should("be.visible")

  cy.get('[data-uipath="ApplyDiscountPopup"]', {timeout:10000}).click()
  cy.wait(2000)
  // // cy.get("[data-uipath='ApplyDiscount/DiscountStrategyModes'] select", {timeout:5000}).click()
  //   cy.get("[data-uipath='ApplyDiscount/DiscountStrategyModes'] .k-select", {timeout:5000}).click()
  //   cy.wait(2000)

  // select apply discount on all groups

  // cy.get('[data-uipath="ApplyDiscount/DiscountStrategyModes"]').find('select').focus().select('All pricing groups', {force:true})

  // cy.wait(2000)

  // cy.get("[data-uipath='ApplyDiscount/DiscountStrategyModes'] select", {timeout:5000}).click()

  // // cy.get('[k-data-source='ChoiceGroupsCache.GetChoiceValues('AdvanceStrategyScope')']').select('All pricing groups')
  // cy.get("[data-uipath='ApplyDiscount/DiscountStrategyModes'] .k-select", {timeout:5000}).click()
cy.wait(2000)

// cy.get('[data-uipath="ApplyDiscount/DiscountStrategyModes"] select').then(function(ddl){

//   ddl.data('kendoDropDownList');
//   ddl.open();
//   ddl.select(ddl.ul.children().filter(function() { return text([this]) == "All pricing groups"; })); 
//   ddl.trigger("change"); ddl.close(); ("[data-uipath='ApplyDiscount/DiscountStrategyModes'] select").change(); 
//   ddl.trigger("change");

// })

// jsExecutor.ExecuteScript("var ddl = $(\"[data-uipath='" + uiPath + "'] select\").data('kendoDropDownList'); 
// ddl.open(); 

// ddl.select(ddl.ul.children().filter(function() { return $.text([this]) === '" + value + "'; })); 
// ddl.trigger('change'); ddl.close(); $(\"[data-uipath='" + uiPath + "'] select\").change();  
// ddl.trigger('change');");



  cy.get('[data-uipath="ApplyDiscount/DiscountStrategyModes"] select', {timeout:5000}).eq(1).click()
  cy.get('[ng-model="AdvanceApplyDiscountModel.StrategyMode"] [value="3"]', {timeout:5000}).click()
  
  // cy.get('#a6d03682-4ad4-47f7-9798-be7888aa5a1f_listbox', {timeout:10000}).eq(1).click()
  
    // insert values in discount
     cy.get('input[ng-model="AdvanceApplyDiscountModel.OneOffStrategyValue"]', {timeout: 6000}).type("10")
  
  cy.get('input[ng-model="AdvanceApplyDiscountModel.RecurringStrategyValue"]', {timeout:60000}).type("10")
  // Click on apply button
  cy.get('[data-uipath="ApplyDiscount/ApplyBtn"]', {timeout:60000}).click()
  
  // click on Yes button on all wizard. 
  cy.get('[data-uipath="YesBtn"]', {timeout:10000}).click()
  
cy.wait(20000)

})

    it("Add New Quote", function () {
      // Click on sales navigator button
      cy.contains("Sales Navigator").click({ force: true });
  
      // Click on create new button
      cy.get('[data-uipath="SalesNavigator/CreateNew"]').click();
  
      // Select Create Quote on wizard
      cy.get('[data-uipath="Model_0"]').click();
  
      // Select Customer on create quote pop up
      cy.get('[data-uipath="quickcreatecmbCustomerId"]').type("Wifinity");
  
      // selecting 1st value form drop down shown after search
      cy.get("#quickcreatecmb_CustomerIdquickcreatelookup_Input_listbox")
        .eq(0)
        .click();
      //Typing name of opportunity
      cy.get("#quickcreatecmb_OpportunityIdquickcreatelookup_Input").type(
        "Selenium Opportunity"
      );
      // Click on Add new button to add opportunity
      cy.get(
        "#quickcreatecmb_OpportunityIdquickcreatelookup_Input-list > .k-nodata > :nth-child(1) > .k-button"
      ).click({ force: true });
      // typing name in contact drop down
      cy.get('[data-uipath="quickcreatecmbContactId"]').type("Selenium Contact");
      // selecting results
      cy.get("#quickcreatecmb_ContactIdquickcreatelookup_Input_listbox")
        .eq(0)
        .click({ force: true });
  
      // typing name in quote name field
      cy.get('[data-uipath="stringName"]').click({force : true}).type("Cypress Test Quote");
  
      // Insert description
      cy.get('.s-textarea-input').type("this is test Cypress quote");
  
      // // Select term
      // cy.get('[data-uipath="numNumberType"]').clear();
      // cy.get('[data-uipath="numNumberType"]').type("36");
      //cy.get('#Quote_Solutions')
      // Click on Next button
      cy.get('[data-uipath="QuickCreate/Next"]').click();
    });
  
    it("Select Solution Type from Quick Create Popup", function () {
      // Selecting Standard Solution
      cy.get("#btnSolutionType0").click();
      // cy.wait(1000);
  
      // Clicking on finish button
      cy.get('[data-uipath="QuickCreate/Next"]').click();
    
    });
  
    it("Verify that quote is created and user is navigator to quote screen", function () {
      // Navigation on Quote and check quote is created.
      cy.wait(5000);
      //cy.get("#QuotesName_inlinelbl").click()
      cy.get("#QuotesName_inlinelbl").should(
        "contain.text",
        "Cypress Test Quote"
      );
      cy.wait(2000);
    });
  
    // it("Search bundle and config products from APB and dragndrop them", function (){
    //   cy.wait(5000);
    //   cy.get('[data-uipath="APB_Item_QuickSearch"]').click()
    //   cy.get('#txtCatalogueBrowser_Input').type('BUNDLESKU8888')
    //   cy.get('[data-uipath="SearchBtn"] > #CatalogueBrowserSearch').click({force: true})
    
    
    //  /*  cy.get('[data-uipath="QuickSearch/SearchProductTree"]').then(function (tr) {
    //     var treelist = tr.data("kendoTreeView");
    //     var exp = treelist.expand("li");
    //   });
    //  */
    //   cy.get('[data-uipath="PlusButton"]').click({force: true})
    // });
    
         
    // || ............................. VERIFY INFORMATION OF QUOTE WIZARD..........................................||
  
    it("Verify Quote Popup Data Persistence", function () {
      // Click on general tab
      cy.get('[data-uipath="QuoteDetail/sidebar/Root/general"]').click();
  
      //...Quote Description
      cy.get("#Description_inlinelbl").should(
        "contain.text",
        "this is test Cypress quote"
      );
  
      //...Quote Term
      cy.get("#QuoteTermNum_inlinelbl").should("contain.text", "24");
    });
  
    // || ............................. UPDATE QUOTE INFORMATION ..........................................||
  
    it("Update Quote Information", function () {
      // update description
      cy.get("#Description_inlinelbl").click();
      cy.get("#Description_Input").type("Updating Quote Description...");
      cy.get('[data-uipath="General/Description/SaveBtn"]').click();
  
      // // .... Updating Payment Terms ....
      cy.get("#PaymentTerms_inlinelbl").click();
      cy.get('[data-uipath="General/PaymentTerm"] .k-select').click();
      cy.get("#PaymentTerms_listbox").contains("60 days").click();
      // cy.get('#globalsearch_SearchText_Input-list').contains('60 days').click()
      cy.get('[data-uipath="General/PaymentTerm/SaveBtn"]').click();
  
      // .... Updating Additional Notes ....
      cy.get('[data-uipath="General/AdditionalNotes"] .inlinelbl').click();
      cy.get("#AdditionalNotes_Input").type("Updating Quote Additional Notes");
      cy.get('[data-uipath="General/AdditionalNotes/SaveBtn"]').click();
  
       // .... Updating Terms and Conditions ....
      cy.get('[data-uipath="General/TermsAndConditions"] .inlinelbl').click();
      cy.get("#TermsAndConditions_Input").type("Updating Terms and Conditions");
      cy.get('[data-uipath="General/TermsAndConditions/SaveBtn"]').click();
      //#TermsAndConditions_Input
      // .... Updating Owner ....
      cy.get('[data-uipath="General/Owner"] .inlinelbl').click();
      cy.get('[data-uipath="General/Owner"] .k-select').click();
      cy.get('[data-uipath="General/Owner"] .k-input').next();
      cy.get('[data-uipath="General/Owner/SaveBtn"]').click();
  
         // .... Updating Contact Person ....
         cy.get('[data-uipath="General/ContactPerson"] .inlinelbl').click();
         cy.get('[data-uipath="General/ContactPerson"] .k-select').click();
         cy.get('#cmbPrimaryContactglookup_Input_listbox > [data-offset-index="3"]').click({force : true})
         cy.get('[data-uipath="General/ContactPerson/SaveBtn"]').click();
      //
    });
    // // || .............................VERIFY QUOTE INFORMATION AFTER UPDATE..........................................||
  
    it("Verify Quote Data after updating quote detail form", function () {
      // Verify the updated quote description
      cy.get("#Description_inlinelbl").should(
        "contain.text",
        "Updating Quote Description..."
      );
      // ....Verify Updated Payment Terms ....
      cy.get('[data-uipath="General/PaymentTerm"] .inlinelbl').should(
        "contain.text",
        "60 days"
      );
  
      // .... Verify Updated Additional Notes ....
      cy.get('[data-uipath="General/AdditionalNotes"] .inlinelbl').should(
        "contain.text",
        "Updating Quote Additional Notes"
      );
  
      // ....Verify Updated Contact Person ...
      cy.get('[data-uipath="General/ContactPerson"] .inlinelbl').should(
        "not.be.empty"
      );
  
      // .... Updating Terms and Conditions ....
      cy.get('[data-uipath="General/TermsAndConditions"] .inlinelbl').should(
        "contain.text",
        "Updating Terms and Conditions"
      );
  
      // Verify that owner is not null
      cy.get('[data-uipath="General/Owner"] .inlinelbl').should("not.be.empty");
  
      // Verify that Contact information is not null
      cy.get('[data-uipath="General/ContactPerson"] .inlinelbl').should(
        "not.be.empty"
      );
  
    });
  
    // || ............................. UPDATE CONTRACT INFORMATION ..........................................||
  
      it('Update Contract Info in General tab', function(){
        cy.get('[data-uipath="QuoteDetail/sidebar/Root/general"]').click()
        cy.wait(2000)
  
      // Click on radio button
        cy.get('[data-uipath="General/ContractUC/ContractUC/IsExistingContract"] input').eq(0).click()
        // CLick on inline lable to edit
        cy.get('[data-uipath="General/ContractUC/ContractUC/ContractLookup"] .inlinelbl').click()
  
        // Click on arrow button
        cy.get('[data-uipath="General/ContractUC/ContractUC/ContractLookup"] .k-select').click()
  
        // Select value
        cy.contains('SeleniumContract').click()
  
        // Save edit box
        cy.get('[data-uipath="General/ContractUC/ContractUC/ContractLookup/SaveBtn"]').click()
  
        // Setting Start Date
        // edit inline label
        cy.get('[data-uipath="General/ContractUC/ContractUC/StartTerm"] .inlinelbl').click()
      // click on arrow
      cy.get('[data-uipath="General/ContractUC/ContractUC/StartTerm"] .k-select').click()
      // select value
      cy.contains('Specific Date').click({force : true})
      // save box
      cy.get('[data-uipath="General/ContractUC/ContractUC/StartTerm/SaveBtn"]').click()
  
      // this is not working as drop down is opening at top of page
    //   // Change the value of Term End
    //   cy.get('[data-uipath="General/ContractUC/ContractUC/EndTerm"] .inlinelbl').click
    //   cy.get('[data-uipath="General/ContractUC/ContractUC/EndTerm"] .k-select').click
    //   cy.contains('Specific Date').click({force : true})
    // cy.get('[data-uipath="General/ContractUC/ContractUC/EndTerm/SaveBtn"]').click()
  
      })
  
    // || ............................. CONTRACT DATA VERIFICATION ..........................................||
  
    it(' G _ Contract data verification', function(){
  
    cy.get('[data-uipath="General/ContractUC/ContractUC/ContractLookup"]').should('contain.text', "SeleniumContract")
  
    })
  
    // || ............................. ADD PRODUCTS IN QUOTE ..........................................||
  
    it("H _ Adding product of multiple LIC from APB Quick search", function () {
      
      // Click on Solutions tab
      cy.get('[data-uipath="QuoteDetail/sidebar/Root/solutionslist"]').click()
      
      //// OPEN AND COLLAPSE PRODUCT BROWSER
      // cy.get(".collapsedGenericPopOver").then(function (lb) {
      //   var btn = lb.eq(1);
      //   btn.click();
      // });
  

      cy.wait(2000);
//

      // open quick search
      cy.contains("Quick Search").click({ force: true });
  
      // searching the products
      cy.get('#txtCatalogueBrowser_Input')
        .type("NoDyn111222");
      
        // ---- Expand the Treeview
      cy.get('[data-uipath="QuickSearch/SearchProductTree"]').then(function (tr) {
        var treelist = tr.data("kendoTreeView");
        var exp = treelist.expand("li");
      });
      
      // clicking on plus button of 1st search result
      cy.get('[data-uipath="PlusButton"]').eq(0).click();
   
  // Add 2nd Product in quote
  cy.get('#CatalogueBrowserClear').eq(0).click({force:true})
    cy.wait(1000)
  
    cy.get('[data-uipath="SearchTextBox"]')
    .eq(1)
    .type("MPrice5555");
    cy.wait(1000)
  
    // ---- Expand the Treeview
  cy.get('[data-uipath="QuickSearch/SearchProductTree"]').then(function (tr) {
    var treelist = tr.data("kendoTreeView");
    var exp = treelist.expand("li");
  });
  
  // clicking on plus button of 1st search result
  cy.get('[data-uipath="PlusButton"]').eq(0).click();
  
    });
      // || ............................. Verification of Quote Totals after adding products from quick search..........................................||

  it("I _ Verification of Quote Totals after adding products from quick search", function(){
  
  // Verification of Quote Total - One Time 
  cy.get('[data-uipath="QuoteDetail/QuoteTotalValue"]').eq(1).should('contain.text','85')
  // Verification of Quote Total - Recurring
  cy.get('[data-uipath="QuoteDetail/QuoteTotalValue"]').eq(0).should('contain.text','16')
  
  })
  // || ............................. Verification of Solution Totals after adding products from quick search..........................................||
    
  it("J _ Verification of Solution Total after adding products from quick search", function(){
  
    // Verification of Quote Total - One Time 
    cy.get('[data-uipath="StandardSolutionTotal"]').eq(1).should('contain.text','85')
    // Verification of Quote Total - Recurring
    cy.get('[data-uipath="StandardSolutionTotal"]').eq(0).should('contain.text','16')
    
    })
  
    //|| ------------------------------- Adding product with Multiple LIC from APB Portfolio search -------------------------------------||

    it('K _ Adding product with Multiple LIC from APB Portfolio search', function(){
  // CLick on back button of APB
  cy.get('[data-uipath="ProductBrowser/APB_BackButton"]').click()
  // click on Portfolio secton
  cy.get('[data-uipath="APB_Item_Portfolio"]').click()
  // Type in search box
  cy.get('[data-uipath="Portfolio/PortfolioTree/SearchTextBox"]').type('CPFLEX7777')
  // clicking on plus button of 1st search result
  cy.get('[data-uipath="PlusButton"]').eq(0).click();
  cy.wait(2000)
  
  // Add 2nd Product from porfolio Search
  
  cy.get('#orgTreeClearBtn').click({force : true})
    cy.wait(1000)
    cy.get('[data-uipath="Portfolio/PortfolioTree/SearchTextBox"]').type('PRICEFLEX6666')
    cy.wait(1000)
    // clicking on plus button of 1st search result
    cy.get('[data-uipath="PlusButton"]').eq(0).click();
    })
  
    
    // || ----------------------- Verification of Quote Totals after adding products from quick search -----------------------------||
  
  it("L _ Verification of Quote Totals after adding products from quick search", function(){
  
    cy.wait(1000)
    // Verification of Quote Total - One Time 
    cy.get('[data-uipath="QuoteDetail/QuoteTotalValue"]').eq(1).should('contain.text','167')
    // Verification of Quote Total - Recurring
    cy.get('[data-uipath="QuoteDetail/QuoteTotalValue"]').eq(0).should('contain.text','52')
    
    })
    
    // || --------------------- Verification of Solution Totals after adding products from quick search ------------------------||
    
    it("M _ Verification of Solution Total after adding products from quick search", function(){
    
      // Verification of Quote Total - One Time 
      cy.get('[data-uipath="StandardSolutionTotal"]').eq(1).should('contain.text','167')
      // Verification of Quote Total - Recurring
      cy.get('[data-uipath="StandardSolutionTotal"]').eq(0).should('contain.text','52')
      
      })
      

// Update cost of Cost price flex product
  it('Quote_N_UpdateProductCost_CostGridDetails', function(){
  

    //             jsExecutor.ExecuteScript("var treelist = $(\"[data-uipath='" + uiPath + "']\").data('kendoTreeList'); treelist.clearSelection(); treelist.select($(\"tr[data-uid='\"+treelist.dataSource.data()['" + selectedIndex + "'].uid+\"']\")); ");
  
  // Select Cost and Price Flex product
    cy.get('[data-uipath="ProductGrid"]').contains('Selenium-CPFlexProduct').click()

// Click on Cost tab
cy.get('#CostHeader').click()
cy.get('tr > :nth-child(9) > .k-button > .k-icon').eq(0).click()
cy.get('#CostHeader').then(function(fn) {

  var ddl = fn.eq(0).data('kendoNumericTextBox');
  ddl.value('30');
  ddl.trigger('change')
})
// Update Cost of product to 30
//jsExecutor.ExecuteScript("var ddl = $(\"[data-uipath='" + uiPath + "'] [data-type='number']:eq('" + selectedRow + "')\").data('kendoNumericTextBox'); ddl.value('" + currentValue + "'); ddl.trigger('change')");

  // .then(function(fn) {
  //   var treelist = fn.data('kendoTreeList')
  //   treelist.clearSelection();
  //   treelist.select("$(\"tr[data-uid='"+treelist.dataSource.data()['2'].uid+"']\")")
  
  // })

  
  })
  
    //       it('Add 2nd product in quote', function(){
  
    //         // click on clear button
    //         cy.get('#CatalogueBrowserClear').eq(0).click({force:true})
    //         cy.wait(2000)
    //  // searching the products
    //  cy.get('[data-uipath="SearchTextBox"]').eq(1).type("servicePath - Basic Version 4")
    //  cy.wait(2000)
    // // Click on Expand Button
    // cy.get(".k-top.k-bot > .k-icon").click();
    // //cy.get("#treeQuickSearch_tv_active .k-icon").click();
    // cy.wait(2000)
    // // clicking on plus button of 1st search result
    // cy.get('[data-uipath="PlusButton"]')
    // .eq(0)
    // .click();
    // cy.wait(5000)
  
    //       })
  
    // Verification of product after adding in quote
    // it("verify that product is added in quote or not", function () {
    //   // check product is added.
    //   cy.get(".editableName")
    //     .contains("servicePath - Basic Version 2")
    //     .should("contain.text", "servicePath - Basic Version 2");
  
    //   cy.wait(2000);
    // });
  
    // it("Update Dynamic Pricing of Product Version", function () {
    //   // Click on cost tab
    //   cy.get("#CostHeader > .k-link").click();
    //   // click on edit button of One-Time Element
    //   cy.get(".k-edit-button").eq(0).click();
  
    //   // Edit cost of one-time element
    //   cy.get('[data-uipath="CostTab"] [data-type="number"]').eq(0).clear();
    //   cy.get('[data-uipath="CostTab"] [data-type="number"]').eq(0).type("10");
  
    //   cy.get(".k-update").click();
  
    //   cy.wait(3000);
  
    //   cy.get(".k-edit-button").eq(0).click();
  
    //   // edit price of one-time element
    //   //cy.get('[data-uipath="CostTab"] [data-type="number"]').eq(1).click()
    //   cy.get('[data-uipath="CostTab"] [data-type="number"]')
    //     .eq(1)
    //     .clear({ force: true });
    //   cy.wait(1000);
    //   cy.get('[data-uipath="CostTab"] [data-type="number"]').eq(1).type("20");
    //   // cy.get('')
    //   // cy.get('.k-textbox .k-input').eq(2).click()
  
    //   // cy.get('.k-textbox .k-input').eq(2).type('20')
  
    //   // Click on save button
    //   cy.get(".k-update").click();
    // });
  
    // it("Inserting value in Line Item Group", function(){
  
    //   cy.get('.k-multiselect-wrap').eq(0).type('Line_Item_Group ')
    //   cy.get('#NewBtn').click({force : true})
  
    // })
  
    // it("Pricing verification on Financial Screen",function(){
  
    //   // Click on Financial dashboad tab
    //   cy.get('[data-uipath="QuoteDetail/sidebar/Root/financialdashboard"]').click();
  
    //   //Check NRR value
    //   cy.get('.kvw-value').eq(0).should("include.text", '50');
  
    //   //Verify TCV
    //   cy.get('.kvw-value').eq(2).should("include.text", '50');
  
    //   //Verify Payback Month
    //   cy.get('.kvw-value').eq(5).should("include.text", '1');
  
    // })
  
    // it("check the Approvals tab", function(){
    // cy.get('#Approvals').click()
  
    // })
  
    // it("Check the Revenue tab", function(){
    //   // click on revenue tab
    // cy.get('#Revenue').click()
  
    // // .row-type-subtotal td:nth-child(2)
    // cy.get('.row-type-subtotal td:nth-child(2)').eq(0).should("include.text", "50");
  
    // // Change the value to monthly
    // cy.get('#Aggregation .k-select').click()
  
    // // Select Quarterly
    // cy.get('#Aggregation-list').contains('By Quarter').click()
  
    // //Change Currency
    // cy.get('#DisplayCurrency .k-select').click()
    // //Select EURO
    // cy.get('#DisplayCurrency-list').contains('Euro').click()
  
    // })
  
    // Add 2nd product in quote and verify the Pricing Group
    // it("this is function to add 2nd product version in quote and verification of pricing Group", function(){
    //   // clicking on cost tab
    //   cy.get('[data-uipath="CostTab"]').eq(0).click()
  
    //   // verifying values
    //   cy.get('tr td:nth-child(7)').eq(0).should('contain.text', "50.00")
    //   cy.get('tr td:nth-child(7)').eq(1).should('contain.text', "50.00")
    //   cy.wait(5000)
  
    //     cy.get('[data-uipath="QuoteDetail/sidebar/Root/financialdashboard"]').click()
    //     // Click on Pricing Screen
    // //    cy.get('#Quote_Pricing_svgicon').click()
    // cy.wait(5000)
  
    // Clear Search box
    // cy.get('#CatalogueBrowserClear').eq(0).click()
    // // Type product name in search
    // cy.get("#txtCatalogueBrowser_Input").click();
    // // searching the products
    // cy.get('[data-uipath="SearchTextBox"]')
    //   .eq(1)
    //   .type("Cypress Basic Version");
  
    // // Click on Expand Button
    // cy.get(".k-top.k-bot > .k-icon").click();
    // //cy.get("#treeQuickSearch_tv_active .k-icon").click();
  
    // clicking on plus button of 1st search result
    // cy.get('[data-uipath="PlusButton"]')
    //   .eq(1)
    //   .click();
  
    // // checking the pricing group on product version
    // cy.get('input[ng-model="SelectedComponentLineItem.PricingGroup"]').should(
    //   "have.value",
    //   "Cypress_Group"
    // );
  
    // })
  
    // });
  
    //cy.SelectPricingGroup(this.data.pricingGroup)
  
    // array.forEach(Element => {
    //   cy.SelectProduct()
    //  });
  
    //     this.data.name.foreach(element => {
    // cy.SelectProduct(element)
    //     })
  
    // cy.SelectProductforEach(name => {
    //       cy.SelectProduct(this.data.name)
    //       cy.SelectPricingGroup('Cypress_Group')
  
    // insert text in search box
    //     cy.get('[data-uipath="Portfolio/PortfolioTree/SearchTextBox"]').type('Cypress Basic Version');
  
    // // select the product version
    // cy.get('.TreeLevelFour').eq(0).click()
    //cy.contains('Cypress Basic Version').click()
  
    // select pricing group field and click inside
    // cy.get('[data-uipath="ProductVersionsSummary/PricingGroup"]').click()
  
    // // Type the pricing group name
  
    // cy.get('#PricingGroup_Input').type('Cypress_Group')
  
    // click on save button
    // cy.get('[data-uipath="ProductVersionsSummary/PricingGroup/SaveBtn"]').click()
  
    // cy.get('#orgTreeClearBtn').click()
    // insert text in search box
  
    // cy.wait(2000)
    // cy.get('[data-uipath="Portfolio/PortfolioTree/SearchTextBox"]').type('Cypress Basic Version 2');
    // cy.wait(2000)
  
    // // select the product version
    // cy.get('.TreeLevelFour').eq(0).click()
  
    // cy.get('[data-uipath="ProductVersionsSummary/PricingGroup"]').click()
  
    // // Type the pricing group name
    // cy.get('#PricingGroup_Input').type('Cypress_Group')
  
    // // click on save button
    // cy.get('[data-uipath="ProductVersionsSummary/PricingGroup/SaveBtn"]').click()
  
    //   })
  
    // })
  
    // it("Select of Pricing Group on 2nd product version", function() {
    //   // click on portfolio
  
    //      // cy.contains("Portfolios").click({ force: true });
    //   //clear search box
    //  cy.get('#orgTreeClearBtn').click()
    //       // insert text in search box
  
    //     cy.wait(2000)
    //      cy.get('[data-uipath="Portfolio/PortfolioTree/SearchTextBox"]').type('Cypress Basic Version 2');
    //      cy.wait(2000)
  
    //   // select the product version
    //   cy.get('.TreeLevelFour').eq(0).click()
  
    //  // select pricing group field and click inside
    //   cy.get('[data-uipath="ProductVersionsSummary/PricingGroup"]').click()
  
    //   // Type the pricing group name
    //   cy.get('#PricingGroup_Input').type('Cypress_Group')
  
    //   // click on save button
    //   cy.get('[data-uipath="ProductVersionsSummary/PricingGroup/SaveBtn"]').click()
    
  });
  // });
  