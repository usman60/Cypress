Given("i open the login page", () => {
    cy.visit("https://preview.solutionengine.co/Spa");
  });
  When("i type in username and password", () => {
    //datatable.hashes().array.forEach(element => {
     cy.get('[data-uipath="LoginForm/UserName"]').type("shehzad");
      cy.get('[data-uipath="LoginForm/Password"]').type("Qqqqq2@");
    //});
  });
  When("i click on login button", () => {
    cy.get('[data-uipath="LoginForm/LoginBtn"]').click();
  });
  Then("{string} should display", (constant) => {
    cy.contains(constant, { timeout: 10000 }).should("be.visible");
  });