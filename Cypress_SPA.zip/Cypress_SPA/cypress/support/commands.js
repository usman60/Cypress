// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add("login", (email, password) => { ... })
///// <reference types="Cypress" />
// import draggable from './draggable'

Cypress.Commands.add("SelectProduct", name => {
  //Clear search
  cy.get("#orgTreeClearBtn").click();

  //search product version
  cy.get('[data-uipath="Portfolio/PortfolioTree/SearchTextBox"]').type(name);
  // select the product version
  cy.wait(1000)
  cy.get(".TreeLevelFour")
    .eq(0)
    .click();
    // cy.wait(10000)

});

Cypress.Commands.add("AddProductInQuote", name => {
  //Clear search
  cy.get("#txtCatalogueBrowser", {timeout:60000}).type(name)
  cy.wait(2000)

	// Expand tree view
	cy.get('[data-uipath="QuickSearch/SearchProductTree"]').then(function (tr) {
		var treelist = tr.data("kendoTreeView");
		var exp = treelist.expand("li");
	  });
    cy.wait(2000)

	  // Add Product version to quote
  cy.get('[data-uipath="PlusButton"]', {timeout: 10000}).eq(0).click()
    cy.wait(2000)

});

Cypress.Commands.add("SelectPricingGroup", pricingGroup => {
  // select pricing group field and click inside
  cy.get('[data-uipath="ProductVersionsSummary/PricingGroup"]').click();

  // Type the pricing group name
  cy.get("#PricingGroup_Input").type(pricingGroup);

  // click on save button
  cy.get('[data-uipath="ProductVersionsSummary/PricingGroup/SaveBtn"]').click();
});

// This is for Login
Cypress.Commands.add("login", (url, username, password) => {
   cy.visit(url);
  cy.get('input[placeholder="User Name"]').type(username);
  cy.get('[data-uipath="LoginForm/Password"]').type(password);
  cy.get('[data-uipath="LoginForm/LoginBtn"]').click();
  cy.wait(10000);
});

Cypress.Commands.add('newSection', () => {
  cy.get('[data-uipath="DefinitionTab/AddSections"]').click({force : true})
  cy.get('[data-uipath="AddSectionPopup/ReadProperties"]').eq(1).click({force : true})
  cy.request('https://selenium.servicepathlive.com/Spa/#/portfolio/productversions/17be24739b829e44/configuratorrules')
  // cy.get('[data-uipath="DefinitionTab/AddSections"]').click()
  cy.get('[data-uipath="DefinitionTab/StepName"]').type('ReadQuantity')
  cy.get('[data-uipath="DefinitionTab/ElementType"]').click({force : true})
  cy.contains('Items').click({force : true}) 
  cy.get('[data-uipath="DefinitionTab/Id"]').click()

  cy.contains('Test item').click()

  cy.get('[data-uipath="DefinitionTab/SetProperty"]').click()
  cy.contains('Quantity').click()

})


import ProductPage from "../integration/pageObject/ProductPage";
import { post } from "cypress/types/jquery";
var product = new ProductPage();

Cypress.Commands.add("SelectProductCypressTest", productName => {
  product.SelectProductCypressTest().each((el, index, list) => {
    var lbl = el.text();
    if (lbl.includes(productName)) {
      //cy.get(".btn").click()
      cy.log(lbl);
      // add to cart button
      product
        .AddtoCart()
        .eq(index)
        .click();
    }
  });
});

let LOCAL_STORAGE_MEMORY = {};

Cypress.Commands.add("saveLocalStorage", () => {
  Object.keys(localStorage).forEach(key => {
    LOCAL_STORAGE_MEMORY[key] = localStorage[key];
  // cy.log(key)
  });
});

Cypress.Commands.add("restoreLocalStorage", () => {
  Object.keys(LOCAL_STORAGE_MEMORY).forEach(key => {
    localStorage.setItem(key, LOCAL_STORAGE_MEMORY[key]);
 // cy.log(key)
  });
});

Cypress.Commands.add('drop', { prevSubject: 'element' }, ($source, selector) => {
  cy.get(selector).then($target => {
    const source = $source[0]
    const target = $target[0]
    cy.get(source).click()
    cy.get(target).click()
    draggable(source, target)
  })
})

Cypress.Commands.add("UpdateProductQtyInQuote", (quantity,index) => {
  cy.get('[data-uipath="ProductGrid"]', { timeout: 60000 }).then(function (treelist) {
    treelist = treelist.data('kendoTreeList');
    var row = treelist.content.find("tr:eq('"+index+"')"); 
    var qty = row.find(".editablefield.quantityEditable"); 
    qty.prev().click(); 
    qty.val(quantity); 
    qty.trigger("blur");
  });
  cy.wait(1000)
});
//
Cypress.Commands.add("AddProductInQuote", name => {
  //Clear search
  cy.get("#txtCatalogueBrowser", {timeout:60000}).type(name)
  cy.wait(2000)

	// Expand tree view
	cy.get('[data-uipath="QuickSearch/SearchProductTree"]').then(function (tr) {
		var treelist = tr.data("kendoTreeView");
		var exp = treelist.expand("li");
	  });
    cy.wait(2000)

	  // Add Product version to quote
  cy.get('[data-uipath="PlusButton"]', {timeout: 10000}).eq(0).click()
    cy.wait(2000)

});
//
// -- This is a child command --
// Cypress.Commands.add("drag", { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add("dismiss", { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite("visit", (originalFn, url, options) => { ... })
